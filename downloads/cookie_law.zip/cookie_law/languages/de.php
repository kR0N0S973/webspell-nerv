<?php
	$_languages = array(
		"description" 				=> "Beschreibung",
		"days" 						=> "Tage",
		"description_info" 			=> "Dieses Feld beinhaltet den Text der im Widget angezeigt werden soll.",
		"days_info" 				=> "Dieses Feld beinhaltet wie lange der Cookie gespeichert wird.",
		"message_success_title" 	=> "Geschafft!",
		"message_success_content" 	=> "Die Änderungen wurden vorgenommen."
	);
?>