<?php
	$_languages = array(
		"description" 			=> "Beschreibung",
		"days" 					=> "Tage",
		"description_info" 		=> "Questo field contiene il testo che verr� dimostrato sul widget.",
		"days_info" 			=> "Questo field contiene il tempo che il cookie verr� salvato."
	);
?>