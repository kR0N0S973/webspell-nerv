<?php
	$_languages = array(
		"description" 			=> "Description",
		"days" 					=> "Days",
		"description_info" 		=> "This field will contain the displayed Text.",
		"days_info" 			=> "This field is the duration of Cookie."
	);
?>